package data;

/**
 * @author giao.lang | fb/giao.lang.bis | youtube/channel/UChsPO5CLUjOWfgwjfC2Y-Wg
 * version 21.06
 */
//HV là 1 HCN (đặc biệt), IS A (KIND OF/VERSION) HCN, tư duy phiên bản
//tư duy series, tư duy kế thừa, vì tao là 1 dạng của mày, tao có mày
//vì tao là 1 dạng của mày, tao sẽ có/kế thừa những thứ mà mày đang có
//Mình là con nhà họ Lê, Phạm, Trần,... chắc chắn mình sẽ đc thừa hưởng hay ho...
//RE-USE KIỂU SẴN CÓ
//logic: khuôn Square làm rất ít thứ, vì HCN làm rồi, mà V là HCN
//cùng kiểu, về chung 1 nhà, xử lí chung đc data, sort chẳng hạn

//HV là sự mở rộng, tiếp nối, phiên bản, chỉnh sửa, độ lại, tinh chỉnh, điều
//chỉnh, hoàn thiện thêm, nâng cấp, tăng cường thêm từ HCN
//1. A extends B, HV extends HCN, HV kế thừa, độ lại từ HCN
//                           HCN đc gọi là (bản gốc): class Cha, parent, super, base
//                                HV phiên bản độ   : class Con, child , sub  , derived

//2. field/instance variables: vì HV là 1 pb của HCN, cho nên những gì HCN có 
//thì HV sẽ có (dĩ nhiên HV cũng sẽ có thêm nhiều điều đb, bàn sau) 
//xài ké của HCN. Ko khai báo những field cho Con (nếu ko có khác biệt) 

//3. phễu vẫn cần có, vì Khuôn cần phễu để đúc, nhận vật liệu
//   Con ko lưu trữ info do giống Cha, sử dụng của Cha, nên phễu COn sẽ đổ
//data từ ngoài vào bên trên Cha
//Các field lúc này nằm bên Cha, phía Cha
//ko tự làm, vì vậy đâu còn gọi là độ từ cái đã có
//   hãy tôn trọng bản sắc của Con, tôn trọng construct của Con
//vì HV, ta sẽ nói về owner, color, edge -> chỉ 1 cạnh khi nói về Vuông


public class Square extends Rectangle {

    public Square(String owner, String color, double edge) {
        super(owner, color, edge, edge);
    }   //~~~ new Rectangle(o, c, w, l);
    //khi gọi phễu tức là sẽ clone vùng new, đổ vào để đúc object
    //dữ liệu vật liệu sẽ chảy vào bên trong vùng new/object
    //new Square() gọi phễu S, tức là đúc/cắt HV
    //logic cắt HV chính là cắt HCN
    //new HV chính là new HCN
       
    
//   private String owner;
//   private String color;
//   private double edge;
   
    //VỀ LÍ THUYẾT, HV ĐÃ XONG, KO CẦN LÀM GÌ THÊM, VÌ INFO ĐC HCN GIỮ GIÙM
    //QUA PHỄU ĐỔ LÊN, HCN (HV) ĐÃ ĐỦ INFO ĐỂ XỬ LÍ, TA KO CẦN LÀM GÌ THÊM
    //TÍNH S() ÉO CẦN, PAINT() ÉO CẦN, GET/SET(), KẾ THỪA, CỨ THẾ MÀ XÀI
    //HOK PHẢI COPY/PASTE
    
    //VỀ TOÁN, VỀ HÓA, THÌ TA CÓ QUYỀN LÀM THÊM CÁI ĐIỀU GÌ MÀ TA THÍCH Ở
    //PHÍA CON
    
    @Override  //đánh dấu 1 điều rằng Con có hàm trùng tên 100% với Cha
    //hiện tượng Con qua mặt Cha, Cha ngồi im đi, để Con xuất hiện, thể hiện
    //phủ quyết, ghi đè, Cha chỉ còn là ý nghĩa, tinh thần hoy, Con mới là thực
    //Con lớn rồi, để Con ra mặt
    //nó dính đến 1 khái niệm quan trọng: tính đa xạ, đa hình, đa ánh xạ, đa sắc
    //thái, 50 sắc thái, biến hình, transformer, biến thiên, đa nhân cách
    //POLYMORPHISM, từ 1 ánh xạ ra nhiều
    
    public void paint() {         //90.0 x 90.0 = 8100.00
        System.out.printf("|SQUARE    |%-15s|%-10s|%4.1f|  - |%7.2f|\n",
                                owner, color, width, getArea());
    }
    
}
