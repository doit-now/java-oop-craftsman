package data;

/**
 * @author giao.lang | fb/giao.lang.bis | youtube/channel/UChsPO5CLUjOWfgwjfC2Y-Wg
 * version 21.06
 */

//HV là phiên bản đb của HCN, độ lại tí, độ lại 2 cạnh kề = nhau
//ko mất đi bản sắc HCN 4 góc vuông
//HV là sự mở rộng, nâng cấp, đặc biệt hóa, phiên bản mới, sự điều
//chỉnh/thay đổi nhỏ từ HCN
//Cách chế tạo Khuôn mới từ Khuôn cũ, kế thừa, dùng lại, đứng trên vai...
//KO PHẢI LÀ COPY&PASTE
//Phiên bản cũ là mình làm các Khuôn từ đầu, ko kế thừa, sp chỏi nhau
//ko cùng 1 nhà đc

//1. mới A extends cũ B: 
//                    HCN Khuôn gốc để độ: class Cha, parent, super, base                 
//       HV               kế thừa từ HCN : class Con, child , sub  , derived
                                                          //biến hình, chế ra từ
                                                          //xuất phát từ
//2. đặc điểm của Con là gì? 
//              Vì HV là (phiên bản) HCN, nên nó sẽ có tất cả mọi thứ từ HCN
//                                  tao là CN, tao phải có những cái HCN đang có
//KO CẦN LÀM LẠI CÁC FIELD/INSTANCE VARS

//3. cần phễu, để đúc phiên bản mới, cần vật liệu đưa vào, gửi Cha giữ, đổ lên
//   Cha, vì có mọi thứ từ Cha, phiên bản gốc
//   tôn trọng bản sắc Con, Con HV, o, c, edge, only edge

//                     Con lại đồng thời là 1 pb HCN, o, c, w, l
//code tự sinh ra nó sẽ căn theo phễu Cha, 4 tham số, để đổ đc 4 tham số
//                               phễu COn phải 4, CHẾT, MẤT BẢN SẮC
//                                                                  EDGE 

public class Square extends Rectangle {

                                            //trade-off
    public Square(String owner, String color, double edge) {
        super(owner, color, edge, edge); //HV có cạnh edge là HCN 2 cạnh edge edge
    }   //~~~ new Rectangle(o, c, w, l);
        //new HV chính là new HCN
        //new HV chính là new 1 phiên bản HCN
       //cắt 1 HV bản chất chính là cắt 1 HCN
       //         có color, own, cạnh -> HCN dưới dạng HV cũng là thế mà
    
//   private String owner;
//   private String color;
//   private double edge;
   
    @Override  //DÍNH ĐẾN 1 KHÁI NIỆM GỌI LÀ TÍNH ĐA HÌNH, ĐA XẠ, ĐA KẾ THỪA
    //ĐA NHÂN CÁCH, ĐA SẮC THÁI, 50 SẮC THÁI, BIẾN HÌNH, TRANSFORMER
    //POLYMORPHISM
    //HIỆN TƯỢNG CON QUA MẶT CHA, THỂ HIỆN BẢN SẮC CỦA CON, CHA NGỒI IM ĐỂ CON
    //LÀM CHO, ĐỂ CON LÊN TIẾNG, CHA ĐỂ ĐÓ ĐI, VỜ NHƯ KO THẤY CHA
    public void paint() {   
        System.out.printf("|SQUARE    |%-15s|%-10s|%4.1f|  - |%7.2f|\n",
                          owner, color, width, getArea());
    }
    
    //VỀ LÍ XONG KHUÔN VUÔNG, VÌ ĐỔ DATA NHƯ TRUYỀN THỐNG, DÙNG LẠI HẾT CỦA CN
}   //KO CẦN VIẾT LẠI CODE, KO COPY & PASTE
    //KO CHỈNH SỬA DÂY CHUYỀN SX QUÁ NHIỀU, TẤT NHIÊN ĐANG CÙNG DÒNG SP, SERIES
