package data;

/**
 * @author giao.lang | fb/giao.lang.bis | youtube/channel/UChsPO5CLUjOWfgwjfC2Y-Wg
 * version 21.06
 */

public class Rectangle {
    private String owner;    //______
    private String color;    //______
    private double width;    //___5___
    private double length;   //___10___
    //private double area;     //___50___ area = w * l
                             //có những đđ đc tính từ những đđ khác
                             //derived field/đặc tính, đặc điểm dẫn xuất (từ đứa khác)
    //cân nhắc khi có dẫn xuất, vì tính nhất quán/đồng bộ data bị - consistency
    //đổ vào từ phễu ko khớp
    //còn cửa bị: setW(cạnh mới) -> quên tính lại S toang
    //lí do nguy hiểm, tao phụ thuộc bởi thằng khác, nó ko im tao có chuyện
    //sl, dg, tt: đổi sl, dg mà quên tính lại thành tiền, toang
    //con của a chị Hai
    //tư duy mới: việc tính toán là việc xử lí data là việc của các hàm
    //dẫn xuất nó nên đc xem là hàm, vì nó có tính toán
    //tính S() xem là hành động/behavior hơn là dẫn xuất
    //lúc giao tiếp, hỏi, tao tính, chính xác luôn luôn 
    

    public Rectangle(String owner, String color, double width, double length) { //area
        this.owner = owner;
        this.color = color;
        this.width = width;
        this.length = length;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    @Override
    public String toString() {
        return "Rectangle{" + "owner=" + owner + ", color=" + color + ", width=" + width + ", length=" + length + '}';
    }
    
    //ai có nhiều info, gã đó phải xử lí
    public double getArea() {
        return width * length; //tao éo in, mục tiêu re-use trong lệnh khác
                               //hàm loại 4
    }
    
    public void paint() {         //90.0 x 90.0 = 8100.00
        System.out.printf("|RECTANGLE |%-15s|%-10s|%4.1f|%4.1f|%7.2f|\n",
                                owner, color, width, length, getArea());
    }
    
}
