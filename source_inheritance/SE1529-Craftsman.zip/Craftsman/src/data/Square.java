package data;

/**
 * @author giao.lang | fb/giao.lang.bis | youtube/channel/UChsPO5CLUjOWfgwjfC2Y-Wg
 * version 21.06
 */

public class Square {
    private String owner;
    private String color;
    private double edge;  //cạnh, 2 cạnh kề = nhau, nói 1 cạnh là đủ

    public Square(String owner, String color, double edge) {
        this.owner = owner;
        this.color = color;
        this.edge = edge;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getEdge() {
        return edge;
    }

    public void setEdge(double edge) {
        this.edge = edge;
    }

    @Override
    public String toString() {
        return "Square{" + "owner=" + owner + ", color=" + color + ", edge=" + edge + '}';
    }
    
    //copy&paste vì thấy gần giống
    //ai có nhiều info, gã đó phải xử lí
    public double getArea() {
        return Math.pow(edge, 2);  //edge^2
        
        //return edge * edge; //tao éo in, mục tiêu re-use trong lệnh khác
                               //hàm loại 4
    }
    
    public void paint() {         //20.0cm   90.5 
        System.out.printf("|SQUARE    |%-15s|%-10s|%4.1f|  - |%7.2f|\n",
                                owner, color, edge, getArea());
    }
    
}
