//OOP: Object Oriented Programming
//                     Paradigm (tư duy, mô thức)
package craftsman;

import data.Disk;
import data.Rectangle;
import data.Square;

/**
 * @author giao.lang | fb/giao.lang.bis | youtube/channel/UChsPO5CLUjOWfgwjfC2Y-Wg
 * version 21.06
 */

public class Craftsman {

    public static void main(String[] args) {
        //cutShapes();
        sortShapes();
    }
    
    //sắp xếp các hình theo S
    public static void sortShapes() {
        Rectangle r1 = new Rectangle("TÍA", "PINK", 1.0, 2.0);
        
        Rectangle rectArr[] = new Rectangle[9];
        //có 9 hình sẽ cắt, 9 biến Rectangle, 9 con trỏ
        //tương đương phòng họp có 9 ghế, 9 chỗ, nhưng chưa ai vào ngồi
        //arr[0], arr[1], arr[2]...
        //                       = trỏ vào vùng new/clone Student(...) Rectangle(...)
        //                         cần lắm luôn 1 tọa độ vùng new (); //object
        //                               éo quan tâm vùng new này cũ hay mới, miễn là new
        //                             new Rectangle(...)
        rectArr[0] = r1;  // 2 chàng 1 nàng, trỏ cùng TÍA
        
//        rectArr[0].paint();  //TÍA
//        
//        rectArr[0].setOwner("TÍA YÊU!!!");
//        System.out.println("Chứng minh 2 chàng 1 nàng");
//        r1.paint();  //TÍA YÊU
        
        rectArr[1] = new Rectangle("MÁ", "PINK", 2.0, 3.0);
        rectArr[2] = new Rectangle("BÉ NA", "RAINBOW", 2.0, 2.0);
        
        rectArr[3] = new Square("GHỆ BÉ NA", "RAINBOW", 1.0);
        
        //chúng mình ko cùng hệ, S éo phải là HCN, ko cùng mảng
        //MẢNG NÓI RẰNG: KHAI BÁO CÙNG KIỂU, MẢNG CHỮ NHẬT CHỈ CHỨA CN
        //MẢNG V CHỈ CHỨA V
        //MÚN SORT TỰ ĐỘNG FOR ALL PHẢI CÙNG MẢNG THÌ MỚI FOR ĐC 
        //V, TR, CN.... PHẢI CÙNG MẢNG GÌ GÌ GÌ ĐÓ, THÌ MỚI FOR
        //TRÊN CÁI GÌ GÌ ĐÓ, ĐẢO VỊ TRÍ THEO DIỆN TÍCH
        
        ??? arr[] = new ???[9];
        arr[0] = new Rectangle(...);
        arr[1] = new Square(...);
        arr[2] = new Disk(...);
        for ??? .getArea() > .getArea()
                
        
        System.out.println("Before sorting");
//        for (Rectangle x : rectArr) {
//            x.paint();  //x = arr[i] = new Rectangle(...)
//        }  //coi chừng toang NULL POINTER, 3/9 đứa đc gán
        for (int i = 0; i < 3; i++) {
            rectArr[i].paint();
        }
        System.out.println("After sorting");
        for (int i = 0; i < 3 - 1; i++) {
            for (int j = i + 1; j < 3; j++) {
                if (rectArr[i].getArea() > rectArr[j].getArea()) {
                    Rectangle t = rectArr[i];
                    rectArr[i] = rectArr[j];
                    rectArr[j] = t;
                }
            }            
        }
        for (int i = 0; i < 3; i++) {
            rectArr[i].paint();
        }
        
    } 
    
    public static void cutShapes() {
        Rectangle r1 = new Rectangle("TÍA", "PINK", 1.0, 2.0);
        r1.paint();
        
        Square s1 = new Square("MÁ", "PINK", 3.0);
        s1.paint();
        
        
        Disk d1 = new Disk("BÉ NA", "RAINBOW", "<3", 2);
        d1.paint();
        
    }
}
