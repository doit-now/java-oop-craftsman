package studentmanagement;

import java.util.Scanner;

/**
 * @author giao.lang | fb/giao.lang.bis | youtube/channel/UChsPO5CLUjOWfgwjfC2Y-Wg
 * version 21.06
 */

public class StudentManagement {

    public static void main(String[] args) {
        //menu để lựa chọn: 1...... 2...... 3....... 4.......
        //chọn hoài đến khi Exit/Quit, lặp, 1 thì addStudent() của Tủ nào????
        int choice;  //lưu lựa chọn
        Scanner sc = new Scanner(System.in);
        Shelf tuSE = new Shelf("PINK", "SE MAJOR");
        

        do {
            printMenu();
            System.out.print("Input your choice (1..6): ");
            choice = Integer.parseInt(sc.nextLine()); //MyToys 
            //if (choice == 1) thì làm gì, == 2 thì làm gì == 3 thì làm gì
            switch (choice) {
                case 1:
                    tuSE.addAStudent();
                    break;
                case 2:
                    tuSE.printStudentList();
                    break;
                case 3:
                    tuSE.searchAStudent();
                    break;  
                case 6:
                    System.out.println("Bye bye, see you next time");
                    break;
                default:
                    System.out.println("Please choose 1..6 to play with");
                    break;

            }
        } while (choice != 6); //chừng nào còn muốn chơi thì cứ chơi
        //chừng nào chưa chọn 6 thì còn chơi, còn đúng còn chơi
        //đúng là chưa = 6 thì chơi tiếp, chưa 6 còn chơi

    }
    
    public static void printMenu() {
        System.out.println("Welcome to FAP - FPT Academic Portal");
        System.out.println("Choose the following funtions to play with");
        System.out.println("1. Add a new student profile");
        System.out.println("2. Print the student");
        System.out.println("3. Search a student by id");
        System.out.println("4. Update a student profile");
        System.out.println("5. Remove a student profile"); //XÓA KO HẲN LÀ XÓA, XÓA LÀ ẨN
        System.out.println("6. Quit");
    }

    public static void checkShelf() {
        //mua Tủ về chứa hồ sơ sv cụ thể nào đó, mỗi tủ default 500 sv
        //OOP thinking, toàn chơi object

        Shelf tuSE = new Shelf("PINK", "SE MAJOR");
        Shelf tuGD = new Shelf("RAINBOW", "GD MAJOR");
        //vòng lặp menu là ngon rồi
        
        tuGD.addAStudent();  //1/500
        System.out.println("The student list for all majors");
        tuSE.printStudentList();
        tuGD.printStudentList();
    }

}
