package studentmanagement;

import java.util.Scanner;

/**
 * @author giao.lang | fb/giao.lang.bis | youtube/channel/UChsPO5CLUjOWfgwjfC2Y-Wg
 * version 21.06
 */

public class Shelf {

    private String color;
    private String label; //nhãn dán tủ để nói tủ đựng loại hồ sơ nao

    //ta focus vào câu chuyện chính: kệ/tủ/phòng chứa những món gì, sinh ra để chứa
    private Student[] arr = new Student[500];
    private int count = 0; //đưa phễu okie, nhưng giá trả là người ta new Tủ (600 món đang có)
    //tăng dần khi mình thêm đồ vào tủ

    private Scanner sc = new Scanner(System.in);  //mua Tủ cài sẵn code

    //một tủ mới mua về, có 0 món đồ...
    //Tủ có sẵn 500 chỗ đựng hồ sơ 
    //new số phần tử là thành công cho biến mảng
    //khai báo mảng là khai báo số biến...
    //mua tủ có số ngăn chứa, chưa quan tâm đồ
    //có nhiều kĩ thuật khởi động kích thước mảng 
    //đổ kích thước mảng qua phễu - Tủ đặt riêng số ngăn
    //new luôn kích thước default khi khai báo Tủ, new Tủ có sẵn kích thước
    //
    //biến thì cần gán value. 
    //primitive = value; //literal 5 10 15 3.14 
    //object thì = new 1 cái gì đó
    //gán trực tiếp ko qua phễu, vì phễu cũng phải đổ vào nó lúc new/clone
    //gán qua phễu 
    //mảng here nghĩa là không gian/khả năng chứa 1 Tủ chưa nói cụ thể từng
    //món đồ
    //biến mảng nó cần phải đc new, hàm ý có bao nhiêu chỗ, new mảng để ở đâu
    //số phần tử mảng 
    //Tủ này đựng hồ sơ sv, sure, ko thể nhét 1 lần 500 hồ sơ, vô lí
    //do đó ta sẽ đưa từ từ từng new Student(hồ sơ cụ thể) vào trong Tủ
    //triết lí: ai có nhiều info, gã đó lo xử lí, hàm thuộc về object
    //đổ màu sắc, label
    //kích thước Tủ có sẵn default 500
    public Shelf(String color, String label) { //int size để new mảng
        this.color = color;
        this.label = label;
        //lí thuyết khi new Shelf() mua Tủ mới, ta có sẵn arr -> 500 biến sv
        //                                               Tủ có 500 chỗ
        //Tủ linh hoạt kích thước, Tủ đặt riêng, đưa size vào đây
        //arr = new Student(size);
    }

    //hành động xử lí data, Tủ có chỗ thì cho nhét đồ/cất đồ  - ADD
    //                      Tủ kiếng thì cho mình xem đc các món đồ - PRINT
    public void addAStudent() {
        //một hồ sơ SV cụ thể sẽ đc lưu vào mảng, mảng lưu đc nhiều data [i] = ???
        //...
        //nhập hồ sơ sv từ bàn phím ~~~~~ đăng kí member của web-site, Scanner, biến tg

        //int count = 0;  //mỗi lần gọi hàm, add() bắt đầu count = 0 vô lí
        //count phải là đđ của Tủ, đầy hay chưa?
        int yob;
        String id, name;
        double gpa;

        System.out.println("Input student #" + (count + 1) + "/" + arr.length);
        //   #1/3   #2/3   #3/3 đời đếm từ 1  
        System.out.print("Input id: ");
        id = sc.nextLine();  //TODO: chặn việc bỏ trắng enter (*)

        System.out.print("Input name: ");
        name = sc.nextLine();

        System.out.print("Input yob: ");
        yob = Integer.parseInt(sc.nextLine()); //MyToys.get();

        System.out.print("Input gpa: ");
        gpa = Double.parseDouble(sc.nextLine()); //MyToys.get();

        arr[count] = new Student(id, name, yob, gpa);
        
        count++; //VIP, quan trọng, giống for chạy slow-motion
        
        System.out.println("Add a new student profile successfully");
    }
    
    //đã có sv nhập vào, mua đồ bỏ vào Tủ, ngắm nghía thoy
    //nhìn qua cửa kiếng, duyệt qua giá sách...
    public void printStudentList() {
        System.out.println("There is/are " + count + " student(s) in the list");
//        for (Student x : arr) {
//            x.showProfile();
//        }  //null pointer đấy
        for (int i = 0; i < count; i++) {
            arr[i].showProfile();
        }
    }
    
    //tui Tủ có nhiều sv, tui offer cái search cho bạn
    //y chang Google tui nhớ đc đặc điểm các website, gõ keyword tui tìm cho
    //gõ mã số sv tui tìm cho
    public void searchAStudent() {
        String id; //mã số sv mún tìm
        System.out.print("Input the id that you want to search: ");
        id = sc.nextLine();
        //quét từ đầu đến count mảng, lôi từng sv ra hỏi, 
        //mã số mấy, == mã id cần tìm hok
        for (int i = 0; i < count; i++) {
            if (arr[i].getId().equalsIgnoreCase(id) == true) {  //so id của sv[i] với id gõ tìm
                //String là object, ko dùng ==, học riêng
                System.out.println("Student found!!! Here he/she is");
                arr[i].showProfile();
                
                return;  //thoát hàm luôn vì tìm thấy duy nhất rồi
            }
        }  //hết for
        
        System.out.println("Student not found!!!");
                
    }

}
