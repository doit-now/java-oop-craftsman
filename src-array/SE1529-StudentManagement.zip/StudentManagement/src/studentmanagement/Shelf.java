package studentmanagement;

import java.util.Scanner;

/**
 * @author giao.lang | fb/giao.lang.bis | youtube/channel/UChsPO5CLUjOWfgwjfC2Y-Wg
 * version 21.06
 */

public class Shelf {

    //mô tả những đặc điểm thường thấy 
    private String color; //_________
    private String label; //_________ 
    //nhãn dán tủ phân loại đồ chứa bên trong
    //nhà sách: sách văn học, kĩ năng mềm...
    //siêu thị y chang 

    //đặc điểm đặc biệt, ta focus vào khi mua 1 Tủ/Kệ, dung lượng, dung tích
    //khả năng chứa các món đồ
    private Student arr[] = new Student[500];  //____bao nhiêu biến Student khác

    private int count = 0;  //đầy hay chưa là đặc trưng của Tủ 
    //default cho count = 0 ko cần linh hoạt, Tủ mới mua, làm gì có đồ bên trong
    //Tủ trống rỗng

    private Scanner sc = new Scanner(System.in);

    //có đặc điểm, thì việc đổ value/gán value cho các đđ này nằm ở đâu
    //color, label: phễu đổ vào
    //arr má mì, tên mảng, cần kích thước, vì mảng là khai báo số biến
    //mỗi biến chứa value gì là câu chuyện khác
    //có vài cách để đưa value cho instance variable
    //gán sẵn value lúc khai báo. Ko linh hoạt, mún theo nhu cầu riêng
    //đưa vào qua phễu. Linh hoạt, new là có value mới
    //đưa qua set()
    //arr = new [số biến student]
    //fix cứng kích thước mảng, ko đưa vào, Tủ đóng sẵn
    public Shelf(String color, String label) { //size: kích thước mảng
        this.color = color;                  //, int count
        this.label = label;                  //   count = 500, 1000?
        //arr = new [size];  //Tủ đặt riêng số ngăn
    }

    //hành động, hàm của 1 object là gì, để đâu
    //nhập hồ sơ sv đưa vào thế nào???
    //nhập từ từ và thuộc cái Tủ/Kệ/Bộ Môn/Trường ĐH, trả việc nhập về cho
    //từng object
    public void addAStudent() {
        //thao tác nhập info của từng sv, sau đó add vào mảng arr
        String id, name;
        int yob;
        double gpa;
        System.out.println("Input student #" + (count + 1) + "/" + arr.length);
        //              lừa đảo số đếm, đời đếm 1, mảng đếm 0
        //                                     #1/500  2/500 3/500  4/5000  5/500... 

        System.out.print("Input id: ");
        id = sc.nextLine();  //MyToys chặn rỗng, nhập sai định dạng Regular Expression
        //TODO: CHẶN KO CHO NHẬP TRÙNG ID, CÒN TRÙNG LÀ CÒN CHỬI
        
        System.out.print("Input name: ");
        name = sc.nextLine();

        System.out.print("Input yob: ");
        yob = Integer.parseInt(sc.nextLine()); //MyToys

        System.out.print("Input gpa: ");
        gpa = Double.parseDouble(sc.nextLine());  //MyToys

        arr[count] = new Student(id, name, yob, gpa);

        count++;  //VIP, có 1 hồ sơ đi vào, thì biến đếm phải tăng để
        //đẩy hồ sơ mới vào vị trí sát bên mảng, trên Kệ để sát kế bên cho ngăn nắp
        System.out.println("Add a new student successfully!");
    }   //i/count chạy kiểu slow-motion, từ từ sẽ đầy, nhưng rải rác kiểu bán vé
    //hàm gọi nhiều lần
    
    //Tủ đã có 1 đống hồ sơ, mình muốn nhìn, xem, 
    public void showStudentList() {
        System.out.println("There is/are " + count + " student(s) in the list");
//        for (Student x : arr) {
//            x.showProfile();
//        }  //dễ chết, null pointer, mảng đã full đâu!!!

        for (int i = 0; i < count; i++) 
            arr[i].showProfile();
        
    }
    
    //ta có nhiều data, ta lo việc xử lí. Search là 1 việc như thế, offfer dịch vụ
    public void searchAStudent() {
        //tìm 1 sv với mã số SE123456
        //thuật toán vét cạn, quét sạch mảng, từ 0...count
        //lôi từng sv[i] hỏi mã số của bạn i, so sánh == mã cần tìm ko, có
        //found tại vị trí i, ko thấy khi đi hết mảng, not found
        String id;
        System.out.print("Input id that you want to search: ");
        id = sc.nextLine();  
        for (int i = 0; i < count; i++) {
            if (arr[i].getId().equalsIgnoreCase(id)) {
                System.out.println("Student found!!! Here she/he is");
                arr[i].showProfile();                
                return;  //mã số sv là duy nhất
            }
        }
        
        //đi hết for mà éo thoát sớm, tức là ko thấy 
        System.out.println("Not found!!!");
    }

}
