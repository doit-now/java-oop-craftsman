package studentmanagement;

import java.util.Scanner;

/**
 * @author giao.lang | fb/giao.lang.bis | youtube/channel/UChsPO5CLUjOWfgwjfC2Y-Wg
 * version 21.06
 */

public class StudentManagement {

    public static void main(String[] args) {
        //menu lựa chọn add hồ sơ từ từ theo kiểu slow-motion
        //chọn 1 để chọn 2 để chọn 3 để
        //1. menu, 2. nhập lựa chọn. 3. tùy chọn gì gọi xử lí tương ứng
        Scanner sc = new Scanner(System.in);
        int choice;
        Shelf tuSE = new Shelf("PINK", "SE MAJOR");
        
        do {
            printMenu();
            System.out.print("Please choose 1..6: ");
            choice = Integer.parseInt(sc.nextLine());  //MyToys
            //if choice == 1 thì choice == 2 thì choice == 3
            switch (choice) {
                case 1:
                    tuSE.addAStudent();
                    break;
                case 2:
                    tuSE.showStudentList();
                    break;
                case 3:
                    tuSE.searchAStudent();
                    break;
                case 6:
                    System.out.println("Bye bye, see you next time");
                    break;
                default:
                    System.out.println("Please choose only 1..6");
                    break;
            }
        } while (choice != 6);  //lặp lại chơi menu đến khi nào chán thì thouy
        //chừng nào chưa chọn 6 thì còn chơi tiếp
        //còn đúng thì còn làm, còn đúng chưa chọn 6 thì còn làm
        //đúng là chưa mún kết thúc, chưa chọn món 6 thì chơi tiếp
        //!= 6 thì chơi tiếp        
    }

    public static void printMenu() {
        //in menu
        System.out.println("Welcome to FAP - FPT Academic Portal");
        System.out.println("Choose the following functions to play with");
        System.out.println("1. Add a new student profile");
        System.out.println("2. Print the student list");
        System.out.println("3. Search a student by id");
        System.out.println("4. Update the student profile");
        System.out.println("5. Remove a student");
        //XÓA KO HẲN LÀ XÓA, XÓA LÀ ẨN INFO
        
        System.out.println("6. Quit");
    }

    public static void checkShelf() {
        //OOP: các loại xuất hiện, hành xử độc lập. Trường ĐH nào, nhập hồ sơ
        //riêng của trường đó
        Shelf tuSE = new Shelf("PINK", "SE MAJOR");
        Shelf tuGD = new Shelf("RAINBOW", "GD MAJOR");

        tuSE.addAStudent();  //#1/500
        tuSE.addAStudent();  //#2/500

        tuGD.addAStudent();  //#1/500

        tuSE.showStudentList();  //2
        tuGD.showStudentList();  //1

    }

}
