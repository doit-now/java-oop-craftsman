﻿========================== PETCARE SYSTEM ver 18.03 ==========================
©2018 by giao-lang | fb/giao.lang.bis | fb/bmag.vn | www.bmag.vn

- Code minh họa bài toán Quản lí Bệnh viện thú cưng cho môn học OOP với Java
- Các tính năng trong APP: CRUD hồ sơ thú cưng
- Các kĩ thuật sử dụng trong APP
  -> Kế thừa (inheritance)
  -> Static
  -> RegularExpression
  -> ArrayList (Collection Framework)
  -> Comparable/Comparator
  -> Anonymous Class
  -> Abstract Class

- Đón xem phiên bản nâng cao dùng Map và tập tin (File)
 
Mọi góp ý từ bá tánh xin đón nhận. Chân thành cảm ơn.
  
            ========================== Ooo ==========================